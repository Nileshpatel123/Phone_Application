package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class AnimationActivity extends AppCompatActivity {

    Boolean animationEnabled;
    TextView animationTarget;

    // for change text size button, increase / decrease the size of 8sp
    float textSizeOffset = 8;
    // for up, down, left, right button click, move the target for 50dp
    float moveOffset = 100;

    // for color changes,
    ArrayList<Integer> colorSet = new ArrayList<Integer>( Arrays.asList(0xFF1DE9B6, 0xFFFFEA00, 0xFFFF3D00, 0xFFD500F9, 0xFF00B0FF));
    int colorIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animation);

        // this guy is the test subject
        animationTarget = findViewById(R.id.txt_animation_target);

        // set init animation status
        animationEnabled = false;
        setStatusText();

        // set animation status
        findViewById(R.id.btn_animation_enable_disable).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animationEnabled = !animationEnabled;
                AnimationActivity.this.setStatusText();
            }
        });

        // button to change text size
        findViewById(R.id.btn_animation_text_size).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeTextSize();
            }
        });

        // button to change background color
        findViewById(R.id.btn_animation_color).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeColorOfTarget();
            }
        });

        // button to move up, down, left, right
        findViewById(R.id.btn_animation_up).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveTarget(0, -moveOffset);
            }
        });
        findViewById(R.id.btn_animation_down).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveTarget(0, moveOffset);
            }
        });
        findViewById(R.id.btn_animation_left).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveTarget(-moveOffset, 0);
            }
        });
        findViewById(R.id.btn_animation_right).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveTarget(moveOffset, 0);
            }
        });

    }


    // update Text of status bar and button based on the value of animation_enabled
    private void setStatusText(){
        if(animationEnabled){
            ((TextView)findViewById(R.id.txt_animation_status)).setText("Animation Enabled");
            ((Button)findViewById(R.id.btn_animation_enable_disable)).setText("Disable");
        } else {
            ((TextView)findViewById(R.id.txt_animation_status)).setText("Animation Disabled");
            ((Button)findViewById(R.id.btn_animation_enable_disable)).setText("Enable");
        }
    }

    private void changeTextSize() {
        if (animationTarget == null) {
            return;
        }
        float txtSizeFrom = animationTarget.getTextSize() / getResources().getDisplayMetrics().scaledDensity;
        float txtSizeTo = txtSizeFrom > 20 ? txtSizeFrom - textSizeOffset : txtSizeFrom + textSizeOffset;
        if(animationEnabled) {
            // use ofFloat to change the size of text
            ObjectAnimator animTxtSize = ObjectAnimator.ofFloat(animationTarget, "textSize", txtSizeFrom, txtSizeTo);
            animTxtSize.start();
        } else {
            animationTarget.setTextSize(txtSizeTo);
        }
    }

    private void changeColorOfTarget()
    {
        if (animationTarget == null)
        {
            return;
        }
        int colorFrom = colorSet.get(colorIndex);
        colorIndex = (colorIndex + 1) % colorSet.size();
        int colorTo = colorSet.get(colorIndex);
        if(animationEnabled)
        {
            // refer to this answer https://stackoverflow.com/questions/2614545/animate-change-of-view-background-color-on-android
            // about how to animate color using ofObject
            ObjectAnimator animColor = ObjectAnimator.ofObject(animationTarget, "backgroundColor", new ArgbEvaluator(), colorFrom, colorTo);
            animColor.start();

        }
        else {
            animationTarget.setBackground(new ColorDrawable(colorSet.get(colorIndex)));
        }
    }
    private void moveTarget(float dx, float dy) {
        if (animationTarget == null) {
            return;
        }

        float transX = animationTarget.getTranslationX() + dx;
        float transY = animationTarget.getTranslationY() + dy;
        if(animationEnabled) {

            // refer to https://developer.android.com/guide/topics/graphics/prop-animation.html#view-prop-animator
            // for how to animate multiple properties
            PropertyValuesHolder pvhX = PropertyValuesHolder.ofFloat("translationX", transX);
            PropertyValuesHolder pvhY = PropertyValuesHolder.ofFloat("translationY", transY);
            ObjectAnimator.ofPropertyValuesHolder(animationTarget, pvhX, pvhY).start();

        } else {
            animationTarget.setTranslationX(transX);
            animationTarget.setTranslationY(transY);
        }

    }
}
