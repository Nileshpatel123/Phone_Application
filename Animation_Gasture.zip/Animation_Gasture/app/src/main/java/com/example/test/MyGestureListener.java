package com.example.test;

import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;

public class MyGestureListener implements
        GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener {
    private String TAG;

    public MyGestureListener(String TAG) {
        this.TAG = TAG;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        Log.d(TAG + "/SingleTapConfirmed", "action = " + MotionEvent.actionToString(e.getAction()));
        return true;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        Log.d(TAG + "/DoubleTap", "action = " + MotionEvent.actionToString(e.getAction()));
        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        Log.d(TAG + "/DoubleTapEvent", "action = " + MotionEvent.actionToString(e.getAction()));
        return true;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        Log.d(TAG + "/Down", "action = " + MotionEvent.actionToString(e.getAction()));
        return true;
    }

    @Override
    public void onShowPress(MotionEvent e) {
        Log.d(TAG + "/ShowPress", "action = " + MotionEvent.actionToString(e.getAction()));
    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        Log.d(TAG + "/SingleTapUp", "action = " + MotionEvent.actionToString(e.getAction()));
        return true;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        Log.d(TAG + "/Scroll", "action1 = " + MotionEvent.actionToString(e1.getAction()));
        Log.d(TAG + "/Scroll", "action2 = " + MotionEvent.actionToString(e2.getAction()));

        return true;
    }

    @Override
    public void onLongPress(MotionEvent e) {
        Log.d(TAG + "/LongPress", "action = " + MotionEvent.actionToString(e.getAction()));
        return;
    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        Log.d(TAG + "/Fling", "action1 = " + MotionEvent.actionToString(e1.getAction()));
        Log.d(TAG + "/Fling", "action2 = " + MotionEvent.actionToString(e2.getAction()));
        return true;
    }
}
