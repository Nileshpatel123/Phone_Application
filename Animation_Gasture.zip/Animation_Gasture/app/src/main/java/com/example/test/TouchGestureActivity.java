package com.example.test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class TouchGestureActivity extends AppCompatActivity {

    private String TAG = this.getClass().getSimpleName();
    private GestureDetectorCompat gdcContainerSide;
    private GestureDetectorCompat gdcContainerTop;
    private GestureDetectorCompat gdcContainerBottom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_touch_gesture);



        findViewById(R.id.touch_container_1).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                String tag = TAG + "/" + "touch_container_1";
                return handleTouchEvent(event, tag);
            }
        });

        MyGestureListener gdListenerContainerSide = new MyGestureListener(TAG + "/" + "touch_container_side/touch_gesture");
        gdcContainerSide = new GestureDetectorCompat(this, gdListenerContainerSide);
        gdcContainerSide.setOnDoubleTapListener(gdListenerContainerSide);
        findViewById(R.id.touch_container_side).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                boolean gestureResult = gdcContainerSide.onTouchEvent(event);
                if(gestureResult) {
                    return true;
                }
                String tag = TAG + "/" + "touch_container_side";
                return handleTouchEvent(event, tag);
            }
        });

        MyGestureListener gdListenerContainerTop = new MyGestureListener(TAG + "/" + "touch_container_top/touch_gesture");
        gdcContainerTop = new GestureDetectorCompat(this, gdListenerContainerTop);
        gdcContainerTop.setOnDoubleTapListener(gdListenerContainerTop);
        findViewById(R.id.touch_container_top).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                boolean gestureResult = gdcContainerTop.onTouchEvent(event);
                if(gestureResult) {
                    return true;
                }
                String tag = TAG + "/" + "touch_container_top";
                return handleTouchEvent(event, tag);
            }
        });


        MyGestureListener gdListenerContainerBottom = new MyGestureListener(TAG + "/" + "touch_container_bottom/touch_gesture");
        gdcContainerBottom = new GestureDetectorCompat(this, gdListenerContainerBottom);
        gdcContainerBottom.setOnDoubleTapListener(gdListenerContainerBottom);

        findViewById(R.id.touch_container_bottom).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                boolean gestureResult = gdcContainerBottom.onTouchEvent(event);
                if(gestureResult) {
                    return true;
                }
                String tag = TAG + "/" + "touch_container_bottom";
                return handleTouchEvent(event, tag);
            }
        });
    }

    private boolean handleTouchEvent(MotionEvent event, String tag) {
        int action = event.getAction();

        switch(action) {
            case (MotionEvent.ACTION_DOWN) :
            case (MotionEvent.ACTION_MOVE) :
            case (MotionEvent.ACTION_UP) :
            case (MotionEvent.ACTION_CANCEL) :
            case (MotionEvent.ACTION_OUTSIDE) :
                Log.d(tag, event.toString());
                return true;
            default :
                Log.d(tag, event.toString());
                return false;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        String tag = TAG + "/" + "TouchGestureActivity";
        return handleTouchEvent(event, tag) ? true : super.onTouchEvent(event);
    }
}
