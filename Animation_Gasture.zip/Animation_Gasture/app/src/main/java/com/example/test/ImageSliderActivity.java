package com.example.test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ImageSliderActivity extends AppCompatActivity {
    private String TAG = this.getClass().getSimpleName();

    private int indicatorActiveColor = 0xAA000000;
    private int indicatorInactiveColor = 0xAAAAAAAA;

    private DisplayMetrics displayMetrics = new DisplayMetrics();

    private ArrayList<ImageView> slider;
    private ArrayList<TextView> indicator;
    private int activeSlider;

    private GestureDetectorCompat mDetector;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_slider);


        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        activeSlider = 0;
        slider = new ArrayList<>();
        slider.add((ImageView)findViewById(R.id.img_slider_s0));
        slider.add((ImageView)findViewById(R.id.img_slider_s1));
        slider.add((ImageView)findViewById(R.id.img_slider_s2));

        indicator = new ArrayList<>();
        indicator.add((TextView) findViewById(R.id.indicator_s0));
        indicator.add((TextView) findViewById(R.id.indicator_s1));
        indicator.add((TextView) findViewById(R.id.indicator_s2));

        showActive();

        dumpSliderStatus();
        mDetector = new GestureDetectorCompat(this, new SliderGestureListener());

    }
    @Override
    public boolean onTouchEvent(MotionEvent event){
        this.mDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }


    private void dumpSliderStatus(){
        String info = "";
        for (int i = 0; i < slider.size(); i++) {
            info = info + "img(" + i + ")" + "[" + slider.get(i).getTranslationX() + "]" + (activeSlider == i ? "*" : "") + " | ";
        }
        Log.d(TAG, info);
    }

    // DO NOT worry about the algorithm in this function, it has nothing to do animation & gesture
    private void showActive(){
        slider.get(activeSlider).setTranslationX(0);
        slider.get(activeSlider).setElevation(1);
        indicator.get(activeSlider).setBackgroundColor(indicatorActiveColor);
        float transX = displayMetrics.widthPixels;;
        for (int i = 0; i < slider.size(); i++) {
            if(i != activeSlider) {
                slider.get(i).setTranslationX(transX);
                slider.get(i).setElevation(0);
                indicator.get(i).setBackgroundColor(indicatorInactiveColor);
            }
        }
    }
    // next == true, show next slide
    // next == false, show previous slide
    private void slide(boolean next) {
        dumpSliderStatus();
        if (next) {
            activeSlider = (activeSlider + 1) % slider.size();
        } else {
            activeSlider = (activeSlider - 1 + slider.size()) % slider.size();
        }
        showActive();
        dumpSliderStatus();
        return;
    }

    // capture gestures
    class SliderGestureListener extends GestureDetector.SimpleOnGestureListener {
        private static final String DEBUG_TAG = "Gestures";

        @Override
        public boolean onDown(MotionEvent event) {
            return true;
        }

        // Fling gestures detected. Depend on the x direction slide the image using animation
        @Override
        public boolean onFling(MotionEvent event1, MotionEvent event2,
                               float velocityX, float velocityY) {
            Log.d(TAG, "onFling: " + velocityX + "/" + velocityY);
            float transX = displayMetrics.widthPixels;;
            if (velocityX >= 0)
            {
                slider.get((activeSlider - 1 + slider.size()) % slider.size()).setTranslationX(0);

                // using animation to slide image
                ObjectAnimator animX = ObjectAnimator.ofFloat(slider.get(activeSlider), "translationX", 0, transX);
                animX.setDuration(500);
                animX.addListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(Animator animation) {
                        return;
                    }

                    @Override
                    public void onAnimationEnd(Animator animation) {
                        Log.d(TAG, "AnimationEnd");
                        slide(false);
                    }

                    @Override
                    public void onAnimationCancel(Animator animation) {
                        return;
                    }

                    @Override
                    public void onAnimationRepeat(Animator animation) {
                        return;
                    }
                });
                animX.start();
            } else {
                slider.get((activeSlider + 1) % slider.size()).setTranslationX(0);
                ObjectAnimator animX = ObjectAnimator.ofFloat(slider.get(activeSlider), "translationX", 0, -transX);
                animX.setDuration(500);
                animX.addListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(Animator animation) {
                        return;
                    }

                    @Override
                    public void onAnimationEnd(Animator animation) {
                        Log.d(TAG, "AnimationEnd");
                        slide(true);
                    }

                    @Override
                    public void onAnimationCancel(Animator animation) {
                        return;
                    }

                    @Override
                    public void onAnimationRepeat(Animator animation) {
                        return;
                    }
                });
                animX.start();
            }

            return true;
        }
    }
}
