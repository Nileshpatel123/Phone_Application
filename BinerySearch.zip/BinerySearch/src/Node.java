
public class Node
{
    Node left;
    int val;
    Node right;
    
    Node(int val)
    {
        this.val=val;
    }
}
