package com.holmesglen.consumingwebapi;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface RemoteSchoolDB
{

    @POST("Students")
    Call<Student> StudentCreate(@Body Student student);

    @GET("Students")
    Call<List<Student>> StudentAll();

    @GET("Students/{id}")
    Call<Student> Student(@Path("id") int id);

    @PUT("Students/{id}")
    Call<Void> StudentUpdate(@Path("id") int id, @Body Student student);

    @DELETE("Students/{id}")
    Call<Student> StudentDelete(@Path("id") int id);

}
