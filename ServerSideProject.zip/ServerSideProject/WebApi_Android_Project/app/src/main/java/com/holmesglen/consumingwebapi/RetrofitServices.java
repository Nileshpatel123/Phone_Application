package com.holmesglen.consumingwebapi;

import android.content.Context;
import android.util.Log;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

class RetrofitServices
{
    // static variable retrofitServicesInstance of type Singleton
    private static RetrofitServices retrofitServicesInstance = null;
    private static RemoteSchoolDB service;

    // private constructor restricted to this class itself
    private RetrofitServices()
    {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://172.20.10.3:5000/api/")  //mOBILE 172.20.10.3 //hOME INTERNET192.168.1.8
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        service = retrofit.create(RemoteSchoolDB.class);
    }

    // static method to create instance of Singleton class
    public static RetrofitServices getInstance()
    {
        if (retrofitServicesInstance == null)
        {
            retrofitServicesInstance = new RetrofitServices();
        }
        return retrofitServicesInstance;
    }

    public void StudentReadOne(int id, final ResultsHandler handler)
    {
        Call<Student> studentReadOne = service.Student(id);

        studentReadOne.enqueue(new Callback<Student>()
        {
            @Override
            public void onResponse(Call<Student> call, Response<Student> response)
            {
                Student student = response.body();
                handler.ReadOneOnResponseHandler(student);
                return;
            }
            @Override
            public void onFailure(Call<Student> call, Throwable t)
            {
                handler.OnFailureHandler();
                return;
            }
        });
        return;
    }

    public void StudentCreate(Student student, final ResultsHandler handler){
        // Prepare API call
        student.setId(0);

        Call<Student> studentCreate = service.StudentCreate(student);
        // Call API
        studentCreate.enqueue(new Callback<Student>()
        {

            // Call API - with successful results
            @Override
            public void onResponse(Call<Student> call, Response<Student> response)
            {
                Student student = response.body();
                handler.CreateOnResponseHandler(student);
                return;
            }

            // Call API - with failed results
            @Override
            public void onFailure(Call<Student> call, Throwable t)
            {
                handler.OnFailureHandler();
                return;
            }
        });

    }

    public void StudentReadAll(final ResultsHandler handler)
    {
        Call<List<Student>> studentReadAll = service.StudentAll();
        studentReadAll.enqueue(new Callback<List<Student>>()
        {

            @Override
            public void onResponse(Call<List<Student>> call, Response<List<Student>> response)
            {
                List<Student> list = response.body();
                handler.ReadAllOnResponseHandler(list);
                return;
            }

            @Override
            public void onFailure(Call<List<Student>> call, Throwable t)
            {
                handler.OnFailureHandler();
                return;
            }
        });
    }

    public void StudentUpdate(int id, Student student, final ResultsHandler handler)
    {
        student.setId(id);
        Call<Void> studentUpdate = service.StudentUpdate(id, student);
        studentUpdate.enqueue(new Callback<Void>(){

            @Override
            public void onResponse(Call<Void> call, Response<Void> response)
            {
                handler.UpdateOnResponseHandler();
                return;
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t)
            {
                return;
            }
        });
    }

    public void StudentDelete(int id, final ResultsHandler handler)
    {
        Call<Student> studentDelete = service.StudentDelete(id);
        studentDelete.enqueue(new Callback<Student>()
        {
            @Override
            public void onResponse(Call<Student> call, Response<Student> response)
            {
                Student student = response.body();
                handler.DeleteOnResponseHandler(student);
                return;
            }

            @Override
            public void onFailure(Call<Student> call, Throwable t)
            {
                handler.OnFailureHandler();
                return;
            }
        });
    }

    public interface ResultsHandler
    {
        void CreateOnResponseHandler(Student student);
        void ReadOneOnResponseHandler(Student student);
        void ReadAllOnResponseHandler(List<Student> studentList);
        void UpdateOnResponseHandler();
        void DeleteOnResponseHandler(Student student);
        void OnFailureHandler();
    }

}
