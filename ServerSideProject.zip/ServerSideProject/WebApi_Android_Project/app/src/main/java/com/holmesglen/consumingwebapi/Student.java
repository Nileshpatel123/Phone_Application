package com.holmesglen.consumingwebapi;

import androidx.annotation.NonNull;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Student
{
    private int id;
    private String firstName;
    private String lastName;
    private String dateOfBirth;

    public Student(String firstName, String lastName, String dateOfBirth) {
        this.id = 0;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
    }
    public Student(int id, String firstName, String lastName, String dateOfBirth) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
    }

    @NonNull
    @Override
    public String toString() {
        return "[ id = " + this.id +
                ", firstName = " + this.firstName +
                ", lastName = " + this.lastName +
                ", dateOfBirth = " + this.dateOfBirth + "]";
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
}
