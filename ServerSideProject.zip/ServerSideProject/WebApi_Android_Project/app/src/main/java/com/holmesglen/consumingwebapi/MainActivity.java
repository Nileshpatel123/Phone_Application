package com.holmesglen.consumingwebapi;

import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RetrofitServices.ResultsHandler
{

    private String TAG = this.getClass().getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         RetrofitServices.getInstance().StudentCreate(new Student("Holmesglen", "Tafe", "1723-06-16"), this);
         RetrofitServices.getInstance().StudentReadAll(this);
         RetrofitServices.getInstance().StudentReadOne(1, this);
         RetrofitServices.getInstance().StudentUpdate(1, new Student("fname-update", "lname-update", "1234-12-21"), this);
         RetrofitServices.getInstance().StudentDelete(1, this);
    }

    @Override
    public void CreateOnResponseHandler(Student student)
    {
        Log.d(TAG, student + " received by MainActivity CreateOnResponseHandler");
    }

    @Override
    public void ReadOneOnResponseHandler(Student student)
    {
        Log.d(TAG, student + " received by MainActivity ReadOneOnResponseHandler");
    }

    public void ReadAllOnResponseHandler(List<Student> studentList)
    {
        Log.d(TAG, studentList + " received by MainActivity ReadAllOnResponseHandler");
    }

    @Override
    public void UpdateOnResponseHandler()
    {
        Log.d(TAG, " received by MainActivity UpdateOnResponseHandler");
    }

    @Override
    public void DeleteOnResponseHandler(Student student) {
        Log.d(TAG, student + " received by MainActivity DeleteOnResponseHandler");
    }

    @Override
    public void OnFailureHandler() {
        Log.d(TAG, " received by MainActivity OnFailureHandler");
    }
}
