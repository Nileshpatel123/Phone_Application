﻿using APIDemo.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIDemo.Database
{
    public class DbContexts : DbContext
    {
        public DbContexts(DbContextOptions<DbContexts> options) : base(options)
        {

        }

        public DbSet<Student> student { get; set; }
    }
}
