package com.example.task2.DatabaseConnection;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.task2.Models.Contact;
import com.example.task2.R;

import java.util.ArrayList;

public class adapterRec extends RecyclerView.Adapter<adapterRec.ItemViewHolder>
{
    public ArrayList<Contact> dataContact;

    public adapterRec(ArrayList<Contact> dataContact)
    {
        this.dataContact = dataContact;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_page, parent, false);
        adapterRec.ItemViewHolder vh = new adapterRec.ItemViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position)
    {
        holder.txtView1.setText(dataContact.get(position).getFirstname());
        holder.txtView2.setText(dataContact.get(position).getLastname());
        holder.txtView3.setText(dataContact.get(position).getPhone());
        holder.txtView4.setText(dataContact.get(position).getDate());
    }

    @Override
    public int getItemCount()
    {
        return dataContact.size();
    }

    public class ItemViewHolder  extends RecyclerView.ViewHolder
    {
        TextView txtView1;
        TextView txtView2;
        TextView txtView3;
        TextView txtView4;

        public Contact contact;

        public ItemViewHolder(@NonNull View itemView)
        {
            super(itemView);
            txtView1 = itemView.findViewById(R.id.textView1);
            txtView2 = itemView.findViewById(R.id.textView2);
            txtView3 = itemView.findViewById(R.id.textView3);
            txtView4 = itemView.findViewById(R.id.textView4);





        }

        /*
        public void bindViews()
        {
            this.txtView1.setText(contact.getFirstname());
            this.txtView2.setText(contact.getLastname());
            this.txtView3.setText(contact.getPhone());
            this.txtView4.setText(contact.getDate());
        }

         */
    }
}
