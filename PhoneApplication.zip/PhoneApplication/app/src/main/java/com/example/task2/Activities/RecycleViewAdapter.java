package com.example.task2.Activities;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.task2.Models.Contact;
import com.example.task2.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.ItemViewHolder> implements Filterable
{
    public ArrayList<Contact> dataContact;
    public ArrayList<Contact> backUp;
    Context context;

    public RecycleViewAdapter(Context context, ArrayList<Contact> dataContact)
    {
        this.context = context;
        this.dataContact = dataContact;
        backUp = new ArrayList<>(dataContact);
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_page, parent, false);
        return new ItemViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position)
    {
        final Contact tempContact = dataContact.get(position);

        holder.txtView1.setText(dataContact.get(position).getFirstname());
        holder.txtView2.setText(dataContact.get(position).getLastname());
        holder.txtView3.setText(dataContact.get(position).getPhone());
        holder.txtView4.setText(dataContact.get(position).getDate());

        holder.itemView.setOnClickListener(view -> {

            Toast.makeText(context,"" + tempContact.getFirstname().toUpperCase(), Toast.LENGTH_SHORT ).show();
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("Firstname", tempContact.getFirstname());
            intent.putExtra("Lastname", tempContact.getLastname());
            intent.putExtra("Phone", tempContact.getPhone());
            intent.putExtra("Date", tempContact.getDate());
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        });

        FloatingActionButton editable = holder.itemView.findViewById(R.id.editfltBtnListPage);
        editable.setOnClickListener(view -> {

            Toast.makeText(context,"" + tempContact.getFirstname().toUpperCase(), Toast.LENGTH_SHORT ).show();
            Intent intent = new Intent(context, EditUpdateActivity.class);
            intent.putExtra("Firstname", tempContact.getFirstname());
            intent.putExtra("Lastname", tempContact.getLastname());
            intent.putExtra("Phone", tempContact.getPhone());
            intent.putExtra("Date", tempContact.getDate());
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        });

        FloatingActionButton deleteBtn = holder.itemView.findViewById(R.id.floatingActionButton4);
        deleteBtn.setOnClickListener(view -> {

            Toast.makeText(context,"" + tempContact.getFirstname().toUpperCase(), Toast.LENGTH_SHORT ).show();
            Intent intent = new Intent(context, DeleteActivity.class);
            intent.putExtra("Firstname", tempContact.getFirstname());
            intent.putExtra("Lastname", tempContact.getLastname());
            intent.putExtra("Phone", tempContact.getPhone());
            intent.putExtra("Date", tempContact.getDate());
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            context.startActivity(intent);
        });
 }
    @Override
    public int getItemCount()
    {
        return dataContact.size();
    }

    @Override
    public Filter getFilter()
    {
        return f;
    }
    Filter f = new Filter()
    {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence)
        {
            ArrayList<Contact>filterList = new ArrayList<>();
            if(charSequence.toString().isEmpty())
            {
                filterList.addAll(backUp);
            }
            else
            {
                for(Contact c: backUp)
                {
                    if(c.getFirstname().toString().toLowerCase().contains(charSequence.toString().toLowerCase()))
                    {
                        filterList.add(c);
                    }
                }
            }

            FilterResults filterResults = new FilterResults();
            filterResults.values = filterList;
            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            dataContact.clear();
            dataContact.addAll((ArrayList<Contact>)filterResults.values);
            notifyDataSetChanged();
        }
    };

    public static class ItemViewHolder  extends RecyclerView.ViewHolder
    {
        public Contact contact;
        TextView txtView1;
        TextView txtView2;
        TextView txtView3;
        TextView txtView4;

        public ItemViewHolder(@NonNull View itemView)
        {
            super(itemView);
            txtView1 = itemView.findViewById(R.id.textView1);
            txtView2 = itemView.findViewById(R.id.textView2);
            txtView3 = itemView.findViewById(R.id.textView3);
            txtView4 = itemView.findViewById(R.id.textView4);
        }
    }
}
