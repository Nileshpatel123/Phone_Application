package com.example.task2.DatabaseConnection;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.DatePicker;

import androidx.annotation.Nullable;

import java.time.DateTimeException;
import java.util.Date;

public class dbManager extends SQLiteOpenHelper {
    private static final String dbName = "dbContact";

    public dbManager(@Nullable Context context) {
        super(context, dbName, null, 1);
    }



    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String query = "create table tbl_contact (id integer primary key autoincrement, fname varchar, lname varchar, phone varchar, date varchar )";
        sqLiteDatabase.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String dropQuery = "DROP TABLE IF EXISTS tbl_contact";
        sqLiteDatabase.execSQL(dropQuery);
        onCreate(sqLiteDatabase);
    }

    public String addRecord(String fname, String lname, String phone, String date)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("fname",fname);
        cv.put("lname",lname);
        cv.put("phone",phone);
        cv.put("date", date);

        float res = db.insert("tbl_contact", null, cv);

        if(res == -1)
        {
            return "Failed";
        }
        else
        {
            return "Successfully Added";
        }
    }
    /*public String addRecord(String fname, String lname, String phone, String date)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("fname",fname);
        cv.put("lname",lname);
        cv.put("phone",phone);
        cv.put("date",date);

        float res = db.insert("tbl_contact", null, cv);

        if(res == -1)
        {
            return "Failed";
        }
        else
        {
            return "Successfully Added";
        }
    }*/

    public String updateRecord(String fname, String lname, String phone, String date)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("fname",fname);
        cv.put("lname",lname);
        cv.put("phone",phone);
        cv.put("date",date);

        float res = db.update("tbl_contact", cv, "fname=?", new String[]{fname});

        if(res == -1)
        {
            return "Failed";
        }
        else
        {
            return "Update Successfully";
        }
    }

    public String deleteRecord(String fname)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        float res = db.delete("tbl_contact","fname=?", new String[]{fname});

        if(res == -1)
        {
            return "Failed";
        }
        else
        {
            return "Delete Successfully";
        }
    }   

    public Cursor readableData()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "select * from tbl_contact order by id desc";

        Cursor cursor = db.rawQuery(query, null);
        return cursor;
    }
}
