package com.example.task2.Models;

import com.example.task2.Models.Contact;

import java.util.ArrayList;
import java.util.Collections;

public class HashTable
{
    private final ArrayList<Contact> hashTable[];// = new ArrayList[27];

    ArrayList<Contact> c = new ArrayList();

    public HashTable()
    {
        hashTable = new ArrayList[27];

        for(int i = 0; i < hashTable.length; i++)
        {
            hashTable[i] = new ArrayList<Contact>();
        }
    }

    public ArrayList<Contact> toList(boolean reverse)
    {
        for(int i = 0; i < hashTable.length; i++)
        {
            for(int j = 0; j < hashTable[i].size(); j++)
            {
                c.add(hashTable[i].get(j));
            }
        }
        if(reverse == true)
        {
            Collections.reverse(c);
        }
            return c;
    }

    public int calcOffsetByKey(int k)
    {
        int offset = 0;
        if (k < 0 || k >= hashTable.length)
        {
            offset = 0;
        }
        else
        {
            for(int i = 0; i < k; i++)
            {
                // offset is the sum of the size of all previous list.
                offset = offset + hashTable[i].size();
            }
        }
        System.out.println("Offset: " + offset);
        return offset;
    }

    // build hash table. use arraylist to resolve collision.
    // sort all arraylists

    public void buildHashTable(ArrayList<Contact> list)
    {
        if(list == null)
        {
            return;
        }

        for(int i = 0; i < list.size(); i++)
        {
            Contact c = list.get(i);
            int hashTableIndex = hash(c.getFirstname());
            hashTable[hashTableIndex].add(c);
        }

        /*for(int i = 0; i < hashTable.length; i++)
        {
            Collections.sort(hashTable[i]);
        }
         */
        //return;
    }

    private int hash(String s)
    {
        if(s == ""){
            return 0;
        }
        char c = s.toUpperCase().charAt(0);
        int asciiValue = (int)c;

        if(asciiValue >= 65 && asciiValue <= 90)
        {
            asciiValue = asciiValue -64;
        }
        else
        {
            asciiValue = 0;
        }
        return asciiValue;
    }

    public void dump()
    {
        for(int i = 0; i < hashTable.length; i++)
        {
            System.out.print("[" + i + "] ");

            for(int j = 0; j < hashTable[i].size(); j++)
            {
                System.out.print("->(" + hashTable[i].get(j).getFirstname() + " / " + hashTable[i].get(j).getPhone() + ")");
            }
                System.out.print("\n");
        }
    }
}
