package com.example.task2.Activities;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.task2.DatabaseConnection.dbManager;
import com.example.task2.DatabaseConnection.fatchData;
import com.example.task2.R;

import java.util.Date;

public class AddActivity extends AppCompatActivity
{
    public EditText fName;
    public EditText lName;
    public EditText phone;
    public EditText date;
    Button addBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_page);
        getSupportActionBar().setTitle("Add New Page");

        fName = findViewById(R.id.addFnameID);
        lName = findViewById(R.id.addLnameID);
        phone = findViewById(R.id.addphoneID);
        date = findViewById(R.id.addDateID);
        addBtn = findViewById(R.id.addButtonID);

        addBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                processInsert(fName.getText().toString(), lName.getText().toString(), phone.getText().toString(), date.getText().toString());
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }

    private void processInsert(String f, String l, String p, String d)
    {
        String res = new dbManager(this).addRecord(f, l, p, d);
        Toast.makeText(getApplicationContext(), res, Toast.LENGTH_SHORT).show();
        fName.setText("");
        lName.setText("");
        phone.setText("");
        date.setText("");
    }
}
