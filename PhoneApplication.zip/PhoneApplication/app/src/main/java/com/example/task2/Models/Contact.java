package com.example.task2.Models;

public class Contact
{
    public String Firstname;
    public String Lastname;
    public String Phone;
    public String Date;

    public Contact(String firstname, String lastname, String phone, String date) {
        Firstname = firstname;
        Lastname = lastname;
        Phone = phone;
        Date = date;
    }

    public String getFirstname() {
        return Firstname;
    }

    public void setFirstname(String firstname) {
        Firstname = firstname;
    }

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String lastname) {
        Lastname = lastname;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
