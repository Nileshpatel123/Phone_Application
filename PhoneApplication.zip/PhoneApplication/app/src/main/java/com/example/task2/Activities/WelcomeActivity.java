package com.example.task2.Activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.example.task2.Pager.ListPage;
import com.example.task2.Pager.SlidePages;
import com.example.task2.Pager.WelcomePage;
import com.example.task2.R;

import java.util.ArrayList;
import java.util.List;

public class WelcomeActivity extends AppCompatActivity
{
    public ViewPager pager;
    public PagerAdapter pagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_page);
        getSupportActionBar().setTitle("Welcome Page");


        /*List<Fragment> list = new ArrayList<>();
        list.add(new WelcomePage());
        list.add(new ListPage());

        pager = findViewById(R.id.welcome_pageID);
        pagerAdapter = new SlidePages(getSupportFragmentManager(), list);
        pager.setAdapter(pagerAdapter);*/
    }

}
