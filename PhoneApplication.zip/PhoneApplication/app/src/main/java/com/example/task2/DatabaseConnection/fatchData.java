package com.example.task2.DatabaseConnection;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.task2.Activities.AddActivity;
import com.example.task2.Activities.DetailActivity;
import com.example.task2.Activities.EditUpdateActivity;
import com.example.task2.Activities.MainActivity;
import com.example.task2.DatabaseConnection.adapterRec;
import com.example.task2.DatabaseConnection.dbManager;
import com.example.task2.Models.Contact;
import com.example.task2.Models.HashTable;
import com.example.task2.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class fatchData extends AddActivity
{
    RecyclerView recyclerView;
    ArrayList<Contact> dataHolder = new ArrayList<>();
    HashTable hash = new HashTable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("List Page");

        recyclerView = findViewById(R.id.main);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Cursor cursor = new dbManager(this).readableData();

        while(cursor.moveToNext())
        {
            Contact contact = new Contact(cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));
            dataHolder.add(contact);
        }

        hash.buildHashTable(dataHolder);
        adapterRec myadapter = new adapterRec(hash.toList(false));
        recyclerView.setAdapter(myadapter);
        ////
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        setAllNavBtnClickListener();

        //declaring all floating buttons and action
        FloatingActionButton addbtn = findViewById(R.id.floatingActionButton);
        FloatingActionButton editbtn = findViewById(R.id.editfltBtnListPage);
        FloatingActionButton deletebtn = findViewById(R.id.floatingActionButton4);

        addbtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                startActivity(new Intent(fatchData.this, AddActivity.class));
            }
        });
        editbtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                startActivity(new Intent(fatchData.this, EditUpdateActivity.class));
            }
        });
        deletebtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                startActivity(new Intent(fatchData.this, DetailActivity.class));
            }
        });
        //finishing all floating buttons and action

    }

    private void navBtnClick(int key)
    {
        if(key < 0 || key > 26)
        {
            return;
        }
        int offset = hash.calcOffsetByKey(key);
        ((LinearLayoutManager)recyclerView.getLayoutManager()).scrollToPositionWithOffset(offset, 0);
    }
    private void setAllNavBtnClickListener()
    {
        findViewById(R.id.btn_main_nav_ee).setOnClickListener((v) -> {
        fatchData.this.navBtnClick(0);
         });

        findViewById(R.id.btn_main_nav_a).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(1);
        });

        findViewById(R.id.btn_main_nav_b).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(2);
        });

        findViewById(R.id.btn_main_nav_c).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(3);
        });

        findViewById(R.id.btn_main_nav_d).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(4);
        });

        findViewById(R.id.btn_main_nav_e).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(5);
        });

        findViewById(R.id.btn_main_nav_f).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(6);
        });

        findViewById(R.id.btn_main_nav_g).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(7);
        });

        findViewById(R.id.btn_main_nav_h).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(8);
        });

        findViewById(R.id.btn_main_nav_i).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(9);
        });

        findViewById(R.id.btn_main_nav_j).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(10);
        });

        findViewById(R.id.btn_main_nav_k).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(11);
        });

        findViewById(R.id.btn_main_nav_l).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(12);
        });

        findViewById(R.id.btn_main_nav_m).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(13);
        });

        findViewById(R.id.btn_main_nav_n).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(14);
        });

        findViewById(R.id.btn_main_nav_o).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(15);
        });
        findViewById(R.id.btn_main_nav_p).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(16);
        });

        findViewById(R.id.btn_main_nav_q).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(17);
        });

        findViewById(R.id.btn_main_nav_r).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(18);
        });

        findViewById(R.id.btn_main_nav_s).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(19);
        });

        findViewById(R.id.btn_main_nav_t).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(20);
        });

        findViewById(R.id.btn_main_nav_u).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(21);
        });

        findViewById(R.id.btn_main_nav_v).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(22);
        });

        findViewById(R.id.btn_main_nav_w).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(23);
        });

        findViewById(R.id.btn_main_nav_x).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(24);
        });

        findViewById(R.id.btn_main_nav_y).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(25);
        });

        findViewById(R.id.btn_main_nav_z).setOnClickListener((v) -> {
            fatchData.this.navBtnClick(26);
        });
    }
}