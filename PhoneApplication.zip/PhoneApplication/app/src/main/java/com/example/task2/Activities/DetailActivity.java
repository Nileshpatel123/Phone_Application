package com.example.task2.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.task2.R;

public class DetailActivity extends AppCompatActivity
{
    TextView firstname, lastname, phone, date;
    String fname, lname, pho, dat;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details_page);
        getSupportActionBar().setTitle("Detail Page");

        Intent intent = getIntent();
        fname = intent.getStringExtra("Firstname");
        lname = intent.getStringExtra("Lastname");
        pho = intent.getStringExtra("Phone");
        dat = intent.getStringExtra("Date");

        firstname = (TextView) findViewById(R.id.detailtextView1);
        lastname = (TextView) findViewById(R.id.detailtextView2);
        phone = (TextView) findViewById(R.id.detailtextView3);
        date = (TextView) findViewById(R.id.detailtextView4);

        firstname.setText(fname);
        lastname.setText(lname);
        phone.setText(pho);
        date.setText(dat);

        Button btn = findViewById(R.id.detailpagebackButtonID);
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}