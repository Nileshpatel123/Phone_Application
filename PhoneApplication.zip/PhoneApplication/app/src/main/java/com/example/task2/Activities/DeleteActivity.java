package com.example.task2.Activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.example.task2.DatabaseConnection.dbManager;


public class DeleteActivity extends AppCompatActivity
{
    String fname;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        fname = intent.getStringExtra("Firstname");

        AlertDialog dailog = new AlertDialog.Builder(this).setTitle("Please Click Ok To").setMessage("Delete " + fname)
                .setPositiveButton("Ok",null).setNegativeButton("Cancle", null).show();

        Button positive = dailog.getButton(AlertDialog.BUTTON_POSITIVE);
        positive.setBackgroundColor(Color.RED);
        positive.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                delete(fname);
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });

        Button nagative = dailog.getButton(AlertDialog.BUTTON_NEGATIVE);
        nagative.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }

    private void delete(String f)
    {
        String res = new dbManager(this).deleteRecord(f);
        Toast.makeText(getApplicationContext(), res, Toast.LENGTH_SHORT).show();
    }
}
