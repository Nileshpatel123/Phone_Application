package com.example.task2.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.task2.DatabaseConnection.dbManager;
import com.example.task2.R;

public class EditUpdateActivity extends AppCompatActivity
{
    EditText firstname, lastname, phone, date;
    String fname, lname, pho, dat;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_page);
        getSupportActionBar().setTitle("Update Page");

        Intent intent = getIntent();
        fname = intent.getStringExtra("Firstname");
        lname = intent.getStringExtra("Lastname");
        pho = intent.getStringExtra("Phone");
        dat = intent.getStringExtra("Date");

        firstname = (EditText) findViewById(R.id.updateFnameID);
        lastname = (EditText) findViewById(R.id.updateLnameID);
        phone = (EditText) findViewById(R.id.updateMobileID);
        date = (EditText) findViewById(R.id.updateDateID);

        firstname.setText(fname);
        lastname.setText(lname);
        phone.setText(pho);
        date.setText(dat);

        Button updateBtn = findViewById(R.id.updateButtonID);
        updateBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                processUpdate(firstname.getText().toString(), lastname.getText().toString(), phone.getText().toString(), date.getText().toString());
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });
    }
    private void processUpdate(String f, String l, String p, String d)
    {
        String res = new dbManager(this).updateRecord(f, l, p, d);
        Toast.makeText(getApplicationContext(), res, Toast.LENGTH_SHORT).show();
        firstname.setText("");
        lastname.setText("");
        phone.setText("");
        date.setText("");
    }
}
