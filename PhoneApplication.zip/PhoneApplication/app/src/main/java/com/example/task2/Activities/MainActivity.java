package com.example.task2.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.task2.DatabaseConnection.dbManager;
import com.example.task2.Models.Contact;
import com.example.task2.Models.HashTable;
import com.example.task2.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    RecyclerView recyclerView;
    ArrayList<Contact> dataHolder = new ArrayList<>();
    HashTable hash = new HashTable();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("MainActivity List Page");
        addData();
        recyclerView = findViewById(R.id.main);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Cursor cursor = new dbManager(this).readableData();
        while(cursor.moveToNext())
        {
            Contact contact = new Contact(cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));
            dataHolder.add(contact);
        }

        hash.buildHashTable(dataHolder);
        RecycleViewAdapter myadapter = new RecycleViewAdapter(getApplicationContext(), hash.toList(false));
        recyclerView.setAdapter(myadapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        setAllNavBtnClickListener();

        SearchView searchview = (SearchView)findViewById(R.id.searchView);
        searchview.setOnQueryTextListener(new SearchView.OnQueryTextListener()
        {
            @Override
            public boolean onQueryTextSubmit(String s)
            {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s)
            {
                myadapter.getFilter().filter(s);
                return false;
            }
        });

        FloatingActionButton addbtn = findViewById(R.id.floatingActionButton);
        addbtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                startActivity(new Intent(MainActivity.this, AddActivity.class));
            }
        });


        FloatingActionButton callbtn = findViewById(R.id.floatingphonecall);
        callbtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                startActivity(new Intent(MainActivity.this, PhoneCall.class));
            }
        });

    }

    private void navBtnClick(int key)
    {
        if(key < 0 || key > 26)
        {
            return;
        }

        int offset = hash.calcOffsetByKey(key);
        ((LinearLayoutManager)recyclerView.getLayoutManager()).scrollToPositionWithOffset(offset, 0);
    }
    private void setAllNavBtnClickListener()
    {
        findViewById(R.id.btn_main_nav_ee).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(0);
        });

        findViewById(R.id.btn_main_nav_a).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(1);
        });

        findViewById(R.id.btn_main_nav_b).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(2);
        });

        findViewById(R.id.btn_main_nav_c).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(3);
        });

        findViewById(R.id.btn_main_nav_d).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(4);
        });

        findViewById(R.id.btn_main_nav_e).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(5);
        });

        findViewById(R.id.btn_main_nav_f).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(6);
        });

        findViewById(R.id.btn_main_nav_g).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(7);
        });

        findViewById(R.id.btn_main_nav_h).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(8);
        });

        findViewById(R.id.btn_main_nav_i).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(9);
        });

        findViewById(R.id.btn_main_nav_j).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(10);
        });

        findViewById(R.id.btn_main_nav_k).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(11);
        });

        findViewById(R.id.btn_main_nav_l).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(12);
        });

        findViewById(R.id.btn_main_nav_m).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(13);
        });

        findViewById(R.id.btn_main_nav_n).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(14);
        });

        findViewById(R.id.btn_main_nav_o).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(15);
        });
        findViewById(R.id.btn_main_nav_p).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(16);
        });

        findViewById(R.id.btn_main_nav_q).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(17);
        });

        findViewById(R.id.btn_main_nav_r).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(18);
        });

        findViewById(R.id.btn_main_nav_s).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(19);
        });

        findViewById(R.id.btn_main_nav_t).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(20);
        });

        findViewById(R.id.btn_main_nav_u).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(21);
        });

        findViewById(R.id.btn_main_nav_v).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(22);
        });

        findViewById(R.id.btn_main_nav_w).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(23);
        });

        findViewById(R.id.btn_main_nav_x).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(24);
        });

        findViewById(R.id.btn_main_nav_y).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(25);
        });

        findViewById(R.id.btn_main_nav_z).setOnClickListener((v) -> {
            MainActivity.this.navBtnClick(26);
        });
    }

    public void addData()
    {
        int i =0 ;

        if(i == 0)
        {
            new dbManager(this).addRecord("Shailesh", "Ganshyam", "04134412220", "12/02/2020");
            new dbManager(this).addRecord("Vinay", "Ganshyam", "0413466660", "12/02/2020");
            new dbManager(this).addRecord("Vishal", "Ganshyam", "0413412322", "12/02/2020");
            new dbManager(this).addRecord("Mehul", "Mahesh", "0413445522", "12/02/2020");
            new dbManager(this).addRecord("Mukesh", "Sam", "0413445452", "12/02/2020");
            new dbManager(this).addRecord("Mark", "Sam", "0413445522", "12/02/2020");
            new dbManager(this).addRecord("Mahesh", "P", "0413488877", "12/02/2020");
            new dbManager(this).addRecord("Mukabhai", "Mukabhai", "0413444444", "12/02/2020");
            new dbManager(this).addRecord("Manih", "Mukabhai", "0413333555", "12/02/2020");
            new dbManager(this).addRecord("Sam", "Patel", "041356666", "12/02/2020");
            new dbManager(this).addRecord("Sarika", "Mahesh", "0411111122", "12/02/2020");
            new dbManager(this).addRecord("Sankar", "Patel", "0413458882", "12/02/2020");
            new dbManager(this).addRecord("Sanya", "Sapna", "04133590002", "12/02/2020");
            new dbManager(this).addRecord("Savita", "Pandit", "04131277872", "12/02/2020");
            new dbManager(this).addRecord("Sapna", "Patni", "041345555", "12/02/2020");
            new dbManager(this).addRecord("Satish", "Aashish", "0410000022", "12/02/2020");
            new dbManager(this).addRecord("Sukhvir", "Rohit", "0413455882", "12/02/2020");
            new dbManager(this).addRecord("Sambha", "Sapna", "0413587122", "12/02/2020");
            new dbManager(this).addRecord("Saroj", "Sapna", "0415544322", "12/02/2020");
            new dbManager(this).addRecord("Don", "Anil", "0413458823", "12/02/2020");
            new dbManager(this).addRecord("Daksha", "Kaushik", "0413136532", "12/02/2020");
            new dbManager(this).addRecord("Dinesh", "Sapna", "04134487990", "12/02/2020");
            new dbManager(this).addRecord("Dinkar", "Sapna", "0413434555", "12/02/2020");
            new dbManager(this).addRecord("Dankil", "Rupesh", "0413442372", "12/02/2020");
            new dbManager(this).addRecord("John", "John", "0413456998", "12/02/2020");
            new dbManager(this).addRecord("Jonder", "Josh", "0413337722", "12/02/2020");
            new dbManager(this).addRecord("Josh", "Jatin", "0413000092", "12/02/2020");
            new dbManager(this).addRecord("Jibra", "Mark", "0413123332", "12/02/2020");
            new dbManager(this).addRecord("Jatin", "Gaurang", "0488865522", "12/02/2020");
            new dbManager(this).addRecord("Mark", "John", "0413443454", "12/02/2020");
            new dbManager(this).addRecord("Gaurang", "Ganesh", "0413498002", "12/02/2020");
            new dbManager(this).addRecord("Gautam", "Anil", "0413423332", "12/02/2020");
            new dbManager(this).addRecord("Ganshyam", "Ganesh", "0415467892", "12/02/2020");
            new dbManager(this).addRecord("Ganesh", "Rakesh", "0413444662", "12/02/2020");
            new dbManager(this).addRecord("Govind", "Anil", "0413442342", "12/02/2020");
            new dbManager(this).addRecord("Rohit", "Anil", "0413455522", "12/02/2020");
            new dbManager(this).addRecord("Anil", "Sapna", "0413445767", "12/02/2020");
            new dbManager(this).addRecord("Shanu", "Anil", "0413445879", "12/02/2020");
        }
        i = i+1;
    }
}