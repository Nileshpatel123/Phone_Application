package com.example.task2.Pager;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import java.util.List;

public class SlidePages extends FragmentStatePagerAdapter
{
    public List<Fragment> fList;

    public SlidePages(FragmentManager fm, List<Fragment> fList)
    {
        super(fm);
        this.fList = fList;
    }

    @NonNull
    @Override
    public Fragment getItem(int position)
    {
        return fList.get(position);
    }

    @Override
    public int getCount()
    {
        return fList.size();
    }
}

