package com.example.task2.Models;

import android.util.Log;

import java.util.ArrayList;

public class Phonebook
{

    /*public static ArrayList<Contact> item;

    public static void initItem()
    {
        item = new ArrayList<>();
        item.add(new Contact("909090", "Nilekjk", "hjhjhj"));
    }*/

    private final String TAG = this.getClass().getSimpleName();

    private static Phonebook db_instance = null;

    public ArrayList<Contact> phonebook;

    public Phonebook()
    {
        phonebook = new ArrayList<Contact>();
        phonebook.add(new Contact("Nilesh", "Patel", "0414741691", "12/03/2021"));
        phonebook.add(new Contact("Adam", "Foster", "0487941454", "21/05/2021"));
        phonebook.add(new Contact("Smith", "Moli", "0423451343", "10/3/2021"));
        phonebook.add(new Contact("Denial", "Zampa", "0476741871", "19/07/2021"));
        phonebook.add(new Contact("Foster", "Taison", "0414741691", "20/09/2021"));
        phonebook.add(new Contact("Gavin", "Kodya", "0418746565", "22/02/2021"));
        phonebook.add(new Contact("Jeff", "Somi", "0416558764", "26/05/2021"));
        phonebook.add(new Contact("Linda", "Rashid", "0465741657", "15/04/2021"));
        phonebook.add(new Contact("John", "Linda", "0414747676", "2/06/2021"));
        phonebook.add(new Contact("Maria", "Tokya", "0465679898", "20/10/2021"));


    }
    public ArrayList<Contact> getAll()
    {

        return (ArrayList<Contact>)phonebook.clone();   //clone method get all contacts
    }
    public static Phonebook getInstance()
    {
        if (db_instance == null)
            db_instance = new Phonebook();

        return db_instance;
    }

    public void addContact(Contact newContact)
    {
        phonebook.add(newContact);
        return;
    }

    public void dumpDB()
    {
        Log.d(TAG, "Dump phonebook data ");
        if (phonebook == null)
        {
            Log.d(TAG, "db not initialized");
        }
        else
        {
            Log.d(TAG, "number of contact: " + phonebook.size());

            for (int i = 0; i < phonebook.size(); i++)
            {
                Contact c = phonebook.get(i);
                Log.d(TAG, "(" + i + ") Name: " + c.getFirstname() +
                        "; Email: " + c.getPhone());
            }
        }
        return;
    }
}
